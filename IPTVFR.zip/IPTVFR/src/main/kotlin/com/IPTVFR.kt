package com.lagradost

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import org.jsoup.Jsoup

class IPTVFR : MainAPI() {
    override var lang = "fr"
    override var mainUrl = "https://witv.store"
    override var name = "03- \ud83d\udcfa IPTV FR \ud83d\udcfa"
    override val hasMainPage = true
    override val hasChromecastSupport = true
    override val supportedTypes = setOf(TvType.Live)

    // Charger la page d'accueil et les catégories
    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val categories = listOf(
            "Toutes les chaines" to mainUrl,
			"Chaines Généraliste" to "$mainUrl/chaines-live/generaliste/",
            "Cinéma" to "$mainUrl/chaines-live/cinema/",
            "Documentaire" to "$mainUrl/chaines-live/documentaire/",
            "Enfants" to "$mainUrl/chaines-live/enfants/",
            "Info" to "$mainUrl/chaines-live/info/",
			"Sport" to "$mainUrl/chaines-live/sport/",
            "Musique" to "$mainUrl/chaines-live/musique/"
        )

        val homePageList = categories.mapNotNull { (categoryName, categoryUrl) ->
            try {
                val document = Jsoup.connect(categoryUrl).get()
                val items = document.select("div.holographic-card").mapNotNull { card ->
                    val isLive = card.select("span.badge.badge-red").text().contains("Live")
                    if (!isLive) return@mapNotNull null

                    val title = card.select("div.ann-short_price").text().trim()
                    val link = fixUrl(card.select("div.ann-short_item > a").attr("href"))
                    val image = fixUrl(card.select("img.xfieldimage.poster").attr("src"))

                    LiveSearchResponse(title, link, this.name, TvType.Live, image)
                }
                if (items.isNotEmpty()) HomePageList(categoryName, items) else null
            } catch (e: Exception) {
                // Gérer les erreurs (par exemple, journaliser l'erreur)
                null
            }
        }

        return HomePageResponse(homePageList)
    }

    // Charger les détails d'un élément (vidéo en direct)
    override suspend fun load(url: String): LoadResponse {
        val document = Jsoup.connect(url).get()

        // Extraire les détails de la vidéo en direct
        val title = document.select("h1").text() // Titre de la vidéo
        val posterUrl = document.select("img.xfieldimage.poster").attr("src") // Poster
        val description = document.select("div.ann-short_price").text() // Description

        // Retourner une réponse de type LiveStreamLoadResponse
        return LiveStreamLoadResponse(
            name = title,
            url = url,
            apiName = this.name, // Nom du plugin
            dataUrl = url, // URL des données (identique à l'URL de la vidéo)
            posterUrl = fixUrl(posterUrl),
            plot = description,
            type = TvType.Live
        )
    }

    // Charger les liens de streaming
  override suspend fun loadLinks(
    data: String,
    isCasting: Boolean,
    subtitleCallback: (SubtitleFile) -> Unit,
    callback: (ExtractorLink) -> Unit
): Boolean {
    return try {
        val document = Jsoup.connect(data).get()
        val iframe = document.select("div.iframe-container iframe").firstOrNull()

        iframe?.let {
            val iframeUrl = fixUrl(it.attr("src"))

            // Extraire l'ID du lien (ex: "/player/playerjs/playerjs.php?id=91")
            val regex = """id=(\d+)""".toRegex()
            val match = regex.find(iframeUrl)

            match?.let {
                val id = it.groupValues[1]  // ID extrait (ex: 91)
                val videoUrl = "https://fremtv.lol:443/WiTVAAMCYNQz4K/WiTVf6pcjxNHUZ/$id.m3u8"

                callback.invoke(
                    ExtractorLink(
                        source = this.name,
                        name = "Witv Live",
                        url = videoUrl,
                        referer = mainUrl,
                        quality = Qualities.Unknown.value,
                        isM3u8 = true
                    )
                )
                return true
            }

            false
        } ?: false
    } catch (e: Exception) {
        e.printStackTrace()
        false
    }
}

}